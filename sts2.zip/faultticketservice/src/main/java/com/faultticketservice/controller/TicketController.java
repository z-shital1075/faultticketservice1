package com.faultticketservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.faultticketservice.dto.TicketDto;
import com.faultticketservice.entity.Ticket;
import com.faultticketservice.service.TicketService;

import lombok.var;

@RestController
@RequestMapping("/tickets")
public class TicketController {

	@Autowired
	TicketService ticketService;

	@PostMapping("/createticket")
	public ResponseEntity<Ticket> createTicket(@RequestBody TicketDto ticketDto) {
//		Ticket ticket = new Ticket();
//		ticket.setType(ticketDto.getType());
//		ticket.setStatus(ticketDto.getStatus());
//		ticket.setDescription(ticketDto.getDescription());
//		ticket.setCreatedBy(ticketDto.getCreatedBy());
//		ticket.setCreatedOn(ticketDto.getCreatedOn());
		Ticket ticket = ticketService.createTicket(ticketDto);
		return new ResponseEntity<>(ticket, HttpStatus.OK);

	}

}
