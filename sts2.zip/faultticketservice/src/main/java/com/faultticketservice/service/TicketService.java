package com.faultticketservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.faultticketservice.dto.TicketDto;
import com.faultticketservice.entity.Ticket;

@Service
public interface TicketService {
	
	public Ticket createTicket(TicketDto ticketdto);
	
	public String modifyTicket(int id, String type, String description, String status);
	
	public String deleteTicketById(int id);
	
	public List<Ticket> viewTicketByType(String type);
	
	public List<Ticket> viewTicketByStatus(String status);

}
