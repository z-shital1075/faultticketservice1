package com.faultticketservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaultticketserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FaultticketserviceApplication.class, args);
	}

}
