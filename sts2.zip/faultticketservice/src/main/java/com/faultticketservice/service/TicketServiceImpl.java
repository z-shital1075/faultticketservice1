package com.faultticketservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.faultticketservice.dto.TicketDto;
import com.faultticketservice.entity.Ticket;
import com.faultticketservice.repository.TicketRepo;

public class TicketServiceImpl implements TicketService {
	
	@Autowired
	private TicketRepo ticketrepo;

	@Override
	public Ticket createTicket(TicketDto ticketdto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyTicket(int id, String type, String description, String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteTicketById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Ticket> viewTicketByType(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Ticket> viewTicketByStatus(String status) {
		// TODO Auto-generated method stub
		return null;
	}

}
